@section('title', $post->title)
@extends('layout')

@section('content')

@include('partials.summary')

@endsection