<?php $__env->startSection('title', 'New Post'); ?>


<?php $__env->startSection('content'); ?>

<h1 class="title">Create a new post</h1>

<form method="post" action="<?php echo e(route('posts.store')); ?>">

    <?php echo csrf_field(); ?>
    <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="field">
        <label class="label">Title</label>
        <div class="control">
            <input type="text" name="title" value="<?php echo e(old('title')); ?>" class="input" placeholder="Title" minlength="5" maxlength="100" required />
        </div>
    </div>

    <div class="field">
        <label class="label">Content</label>
        <div class="control">
            <textarea name="content" class="textarea" placeholder="Content" minlength="5" maxlength="2000" required rows="10"><?php echo e(old('content')); ?></textarea>
        </div>
    </div>

    <div class="field">
        <label class="label">Category</label>
        <div class="control">
            <div class="select">
                <select name="category" required>
                    <option value="" disabled selected>Select category</option>
                    <option value="html" <?php echo e(old('category') === 'html' ? 'selected' : null); ?>>HTML</option>
                    <option value="css" <?php echo e(old('category') === 'css' ? 'selected' : null); ?>>CSS</option>
                    <option value="javascript" <?php echo e(old('category') === 'javascript' ? 'selected' : null); ?>>JavaScript</option>
                    <option value="php" <?php echo e(old('category') === 'php' ? 'selected' : null); ?>>PHP</option>
                </select>
            </div>
        </div>
    </div>

    <div class="field">
        <div class="control">
            <button type="submit" class="button is-link is-outlined">Publish</button>
        </div>
    </div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\AdvanceBlog\resources\views/posts/create.blade.php ENDPATH**/ ?>