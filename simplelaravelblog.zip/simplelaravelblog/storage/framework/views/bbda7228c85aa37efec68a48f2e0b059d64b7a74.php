<div class="content">
    <a href="<?php echo e(route('posts.show', [$post->slug])); ?>">
      <h1 class="title"><?php echo e($post->title); ?></h1>
    </a>
    <p><b>Posted:</b> <?php echo e($post->created_at->diffForHumans()); ?></p>
    <p><b>Category:</b> <?php echo e($post->category); ?></p>
    <p><?php echo nl2br(e($post->content)); ?></p>
  
    <form method="post" action="<?php echo e(route('posts.destroy', [$post->slug])); ?>">
      <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
      <div class="field is-grouped">
        <div class="control">
          <a
            href="<?php echo e(route('posts.edit', [$post->slug])); ?>"
            class="button is-info is-outlined"
          >
            Edit
          </a>
        </div>
        <div class="control">
          <button type="submit" class="button is-danger is-outlined">
            Delete
          </button>
        </div>
      </div>
    </form>
  </div><?php /**PATH C:\laragon\www\AdvanceBlog\resources\views/partials/summary.blade.php ENDPATH**/ ?>